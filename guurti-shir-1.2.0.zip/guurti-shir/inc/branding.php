<?php
/**
 * Branding: official emblem as site logo + favicon, bundled photo helpers.
 *
 * @package guurti-shir
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * On activation, import the bundled emblem into the Media Library and use it as the
 * site logo (and site icon). Never overrides a logo the site owner already chose.
 */
function guurti_shir_install_logo() {
	if ( get_theme_mod( 'custom_logo' ) ) {
		return;
	}
	$src = get_theme_file_path( 'assets/images/logo.png' );
	if ( ! file_exists( $src ) ) {
		return;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$tmp = wp_tempnam( 'golaha-guurtida-logo.png' );
	if ( ! $tmp || ! copy( $src, $tmp ) ) {
		return;
	}
	$id = media_handle_sideload(
		array(
			'name'     => 'golaha-guurtida-logo.png',
			'tmp_name' => $tmp,
		),
		0,
		'Golaha Guurtida – official emblem'
	);
	if ( is_wp_error( $id ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		return;
	}
	update_post_meta( $id, '_wp_attachment_image_alt', 'Golaha Guurtida – House of Elders emblem' );
	set_theme_mod( 'custom_logo', $id );
	if ( ! get_option( 'site_icon' ) ) {
		update_option( 'site_icon', $id );
	}
}
add_action( 'after_switch_theme', 'guurti_shir_install_logo', 20 );

/**
 * If no logo is set (or the import failed), the Site Logo block still shows the bundled emblem.
 *
 * @param string $content Block HTML.
 * @param array  $block   Parsed block.
 * @return string
 */
function guurti_shir_logo_fallback( $content, $block ) {
	if ( '' !== trim( $content ) ) {
		return $content;
	}
	$w = ! empty( $block['attrs']['width'] ) ? (int) $block['attrs']['width'] : 56;
	return sprintf(
		'<div class="wp-block-site-logo"><a href="%1$s" class="custom-logo-link" rel="home"><img class="custom-logo" src="%2$s" width="%3$d" height="%3$d" alt="%4$s" decoding="async"></a></div>',
		esc_url( home_url( '/' ) ),
		esc_url( get_theme_file_uri( 'assets/images/logo-192.png' ) ),
		$w,
		esc_attr( get_bloginfo( 'name' ) )
	);
}
add_filter( 'render_block_core/site-logo', 'guurti_shir_logo_fallback', 10, 2 );

/**
 * Favicon fallback when no Site Icon is set.
 */
function guurti_shir_favicon() {
	if ( function_exists( 'has_site_icon' ) && has_site_icon() ) {
		return;
	}
	$icon = esc_url( get_theme_file_uri( 'assets/images/logo-192.png' ) );
	echo '<link rel="icon" href="' . $icon . '" sizes="192x192" type="image/png">' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<link rel="apple-touch-icon" href="' . $icon . '">' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}
add_action( 'wp_head', 'guurti_shir_favicon', 3 );
add_action( 'admin_head', 'guurti_shir_favicon', 3 );
add_action( 'login_head', 'guurti_shir_favicon', 3 );

/**
 * Emblem on the WordPress login screen.
 */
function guurti_shir_login_logo() {
	$logo = esc_url( get_theme_file_uri( 'assets/images/logo-192.png' ) );
	echo '<style>#login h1 a{background-image:url(' . $logo . ');background-size:contain;background-repeat:no-repeat;width:120px;height:120px}</style>'; // phpcs:ignore WordPress.Security.EscapeOutput
}
add_action( 'login_enqueue_scripts', 'guurti_shir_login_logo' );
add_filter( 'login_headerurl', 'home_url' );
