<?php
/**
 * Secure contact form: [guurti_contact_form]
 * Sends to the site administrator email (Settings > General).
 *
 * @package guurti-shir
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function guurti_shir_contact_shortcode() {
	$status = isset( $_GET['guurti_msg'] ) ? sanitize_key( wp_unslash( $_GET['guurti_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	ob_start();
	if ( 'sent' === $status ) {
		echo '<div class="guurti-alert" role="status"><span class="is-en">Thank you. Your message has been sent.</span><span class="is-so">Mahadsanid. Fariintaada waa la diray.</span></div>';
	} elseif ( 'error' === $status ) {
		echo '<div class="guurti-alert" role="alert" style="border-color:#a33"><span class="is-en">Your message could not be sent. Please check the fields and try again.</span><span class="is-so">Fariinta lama diri karin. Fadlan hubi qaybaha oo mar kale isku day.</span></div>';
	}
	?>
	<form class="guurti-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="guurti_contact">
		<?php wp_nonce_field( 'guurti_contact', 'guurti_contact_nonce' ); ?>
		<p class="hp" aria-hidden="true"><label>Leave empty <input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>
		<label><span><span class="is-en">Full name</span><span class="is-so">Magaca oo buuxa</span></span><input type="text" name="g_name" required maxlength="120" autocomplete="name"></label>
		<label><span><span class="is-en">Email</span><span class="is-so">Iimaylka</span></span><input type="email" name="g_email" required maxlength="120" autocomplete="email"></label>
		<label><span><span class="is-en">Subject</span><span class="is-so">Mawduuca</span></span><input type="text" name="g_subject" required maxlength="160"></label>
		<label><span><span class="is-en">Message</span><span class="is-so">Fariinta</span></span><textarea name="g_message" rows="6" required maxlength="4000"></textarea></label>
		<button type="submit"><span class="is-en">Send message</span><span class="is-so">Dir fariinta</span></button>
	</form>
	<?php
	return ob_get_clean();
}
add_shortcode( 'guurti_contact_form', 'guurti_shir_contact_shortcode' );

function guurti_shir_contact_handler() {
	$back = wp_get_referer() ? remove_query_arg( 'guurti_msg', wp_get_referer() ) : home_url( '/' );
	if ( ! isset( $_POST['guurti_contact_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['guurti_contact_nonce'] ) ), 'guurti_contact' ) ) {
		wp_safe_redirect( add_query_arg( 'guurti_msg', 'error', $back ) );
		exit;
	}
	if ( ! empty( $_POST['website'] ) ) { // Honeypot.
		wp_safe_redirect( add_query_arg( 'guurti_msg', 'sent', $back ) );
		exit;
	}
	$ip   = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key  = 'guurti_rl_' . md5( $ip );
	$hits = (int) get_transient( $key );
	if ( $hits >= 5 ) {
		wp_safe_redirect( add_query_arg( 'guurti_msg', 'error', $back ) );
		exit;
	}
	set_transient( $key, $hits + 1, HOUR_IN_SECONDS );

	$name    = isset( $_POST['g_name'] ) ? sanitize_text_field( wp_unslash( $_POST['g_name'] ) ) : '';
	$email   = isset( $_POST['g_email'] ) ? sanitize_email( wp_unslash( $_POST['g_email'] ) ) : '';
	$subject = isset( $_POST['g_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['g_subject'] ) ) : '';
	$message = isset( $_POST['g_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['g_message'] ) ) : '';

	if ( '' === $name || ! is_email( $email ) || '' === $subject || '' === $message ) {
		wp_safe_redirect( add_query_arg( 'guurti_msg', 'error', $back ) );
		exit;
	}
	$to      = apply_filters( 'guurti_shir_contact_recipient', get_option( 'admin_email' ) );
	$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );
	$ok      = wp_mail( $to, '[' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . '] ' . $subject, "From: $name <$email>\n\n$message", $headers );
	wp_safe_redirect( add_query_arg( 'guurti_msg', $ok ? 'sent' : 'error', $back ) );
	exit;
}
add_action( 'admin_post_nopriv_guurti_contact', 'guurti_shir_contact_handler' );
add_action( 'admin_post_guurti_contact', 'guurti_shir_contact_handler' );
