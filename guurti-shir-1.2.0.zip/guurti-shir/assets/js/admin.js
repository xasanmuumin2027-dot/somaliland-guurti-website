/* Media Library picker for document fields. */
jQuery(function ($) {
  $(document).on('click', '.guurti-pick', function (e) {
    e.preventDefault();
    var target = $('#' + $(this).data('target'));
    var frame = wp.media({ title: 'Choose document', multiple: false });
    frame.on('select', function () {
      target.val(frame.state().get('selection').first().toJSON().url);
    });
    frame.open();
  });
});
