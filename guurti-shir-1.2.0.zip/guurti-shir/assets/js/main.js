/* Language switch, sticky header state, and restrained GSAP motion. */
(function () {
  var doc = document.documentElement;

  /* ---- Language ---- */
  function applyLang(l) {
    l = l === 'so' ? 'so' : 'en';
    doc.setAttribute('data-lang', l);
    doc.lang = l;
    try { localStorage.setItem('guurti-lang', l); } catch (e) {}
    document.querySelectorAll('.lang-switch button').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-set-lang') === l));
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-set-lang]');
    if (b) applyLang(b.getAttribute('data-set-lang'));
  });
  applyLang(doc.getAttribute('data-lang'));

  /* ---- Header shadow ---- */
  var header = document.querySelector('.guurti-header');
  if (header) {
    var onScroll = function () { header.classList.toggle('is-scrolled', window.scrollY > 12); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---- Motion ---- */
  if (!doc.classList.contains('js-motion') || !window.gsap) return;
  var gsap = window.gsap;
  if (window.ScrollTrigger) gsap.registerPlugin(window.ScrollTrigger);

  // One orchestrated hero entrance.
  var hero = document.querySelector('.guurti-hero__inner');
  if (hero) {
    gsap.from(hero.children, { y: 28, opacity: 0, duration: 1, ease: 'power3.out', stagger: 0.12, delay: 0.1, clearProps: 'all' });
  }

  // Section headings and card groups reveal once as they enter.
  var targets = document.querySelectorAll('.guurti-heading, .guurti-cards .wp-block-post-template > li, .guurti-stat, .guurti-session');
  targets.forEach(function (el) { el.classList.add('g-reveal'); });
  if (window.ScrollTrigger) {
    window.ScrollTrigger.batch('.g-reveal', {
      start: 'top 88%', once: true,
      onEnter: function (batch) {
        gsap.to(batch, { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out', stagger: 0.08, overwrite: true, onComplete: function () { batch.forEach(function (n) { n.classList.add('is-in'); n.style.cssText = ''; }); } });
      }
    });
  } else {
    targets.forEach(function (el) { el.classList.add('is-in'); });
  }

  // Count-up for statistics that contain a real number (placeholders like "—" are left alone).
  document.querySelectorAll('.guurti-stat .num').forEach(function (n) {
    var v = parseInt(n.textContent.replace(/[^\d]/g, ''), 10);
    if (!v || !/^\s*[\d,.\s]+\s*$/.test(n.textContent)) return;
    var o = { x: 0 };
    window.ScrollTrigger && window.ScrollTrigger.create({
      trigger: n, start: 'top 90%', once: true,
      onEnter: function () { gsap.to(o, { x: v, duration: 1.6, ease: 'power2.out', onUpdate: function () { n.textContent = Math.round(o.x).toLocaleString(); } }); }
    });
  });

  /* ---- v1.2 motion: portraits, welcome, about, progress, hero depth ---- */
  var ST = window.ScrollTrigger;
  if (ST) {
    // Scroll progress bar
    var bar = document.createElement('div'); bar.className = 'guurti-progress'; bar.setAttribute('aria-hidden', 'true');
    document.body.appendChild(bar);
    gsap.to(bar, { scaleX: 1, ease: 'none', scrollTrigger: { start: 0, end: 'max', scrub: 0.3 } });

    // Hero depth: content drifts up and fades slowly as you scroll away
    var heroEl = document.querySelector('.guurti-hero');
    var heroIn = document.querySelector('.guurti-hero__inner');
    if (heroEl && heroIn) {
      gsap.to(heroIn, { yPercent: -12, opacity: 0.25, ease: 'none', scrollTrigger: { trigger: heroEl, start: 'top top', end: 'bottom top', scrub: true } });
    }

    // Welcome: rotating gold orbit + speaker / secretary portraits
    var welcome = document.querySelector('.guurti-welcome');
    if (welcome) {
      var orbit = document.createElement('div'); orbit.className = 'guurti-orbit'; orbit.setAttribute('aria-hidden', 'true');
      welcome.appendChild(orbit);
      gsap.to(orbit, { rotation: 180, ease: 'none', scrollTrigger: { trigger: welcome, start: 'top bottom', end: 'bottom top', scrub: 1 } });
      gsap.from(orbit, { scale: 0.6, opacity: 0, duration: 1.6, ease: 'power3.out', scrollTrigger: { trigger: welcome, start: 'top 80%', once: true } });

      var textCol = welcome.querySelector('.wp-block-column:last-child');
      if (textCol) {
        gsap.from(textCol.children, { x: 40, opacity: 0, duration: 1, ease: 'power3.out', stagger: 0.14, clearProps: 'all', scrollTrigger: { trigger: textCol, start: 'top 80%', once: true } });
      }
    }

    document.querySelectorAll('.guurti-person').forEach(function (p, i) {
      var fig = p.querySelector('.guurti-portrait__img');
      var img = fig && fig.querySelector('img');
      var frame = p.querySelector('.guurti-portrait');
      var cap = p.querySelector('.guurti-person__cap');
      if (!fig || !img) return;
      var tl = gsap.timeline({ scrollTrigger: { trigger: p, start: 'top 85%', once: true }, delay: 0.05 });
      tl.fromTo(fig, { clipPath: 'inset(0 0 100% 0)' }, { clipPath: 'inset(0 0 0% 0)', duration: 1.3, ease: 'power4.inOut', clearProps: 'clipPath' }, 0)
        .fromTo(img, { scale: 1.45 }, { scale: 1.12, duration: 1.8, ease: 'power3.out' }, 0)
        .from(frame, { outlineOffset: -14, outlineColor: 'rgba(185,154,75,0)', duration: 1.2, ease: 'power2.out', clearProps: 'outlineOffset,outlineColor' }, 0.5);
      if (cap) {
        tl.from(cap, { '--lx': 0, duration: 0.01 }, 0.7)
          .to(cap, { '--lx': 1, duration: 0.8, ease: 'power3.out' }, 0.7)
          .from(cap.querySelectorAll('p'), { y: 24, opacity: 0, duration: 0.8, ease: 'power3.out', stagger: 0.1, clearProps: 'all' }, 0.8);
      }
      // gentle parallax inside the frame (scale 1.12 leaves a safe margin)
      gsap.fromTo(img, { yPercent: -4 }, { yPercent: 4, ease: 'none', scrollTrigger: { trigger: p, start: 'top bottom', end: 'bottom top', scrub: true } });
    });

    // About: paragraph cascade, pillars (line draw + number count), slogan word reveal
    var about = document.querySelector('.guurti-about');
    if (about) {
      about.querySelectorAll('.guurti-about__cols .wp-block-column').forEach(function (col) {
        var items = Array.prototype.filter.call(col.children, function (n) { return getComputedStyle(n).display !== 'none'; });
        gsap.from(items, { y: 34, opacity: 0, duration: 0.9, ease: 'power3.out', stagger: 0.12, clearProps: 'all', scrollTrigger: { trigger: col, start: 'top 85%', once: true } });
      });
      var pillars = about.querySelectorAll('.guurti-pillar');
      if (pillars.length) {
        gsap.from(pillars, { y: 50, opacity: 0, duration: 0.9, ease: 'power3.out', stagger: 0.14, clearProps: 'transform,opacity', scrollTrigger: { trigger: pillars[0], start: 'top 90%', once: true } });
        pillars.forEach(function (pl, k) {
          gsap.fromTo(pl, { '--lx': 0 }, { '--lx': 1, duration: 1, ease: 'power3.out', delay: 0.2 + k * 0.14, scrollTrigger: { trigger: pillars[0], start: 'top 90%', once: true } });
          var num = pl.querySelector('.guurti-pillar__num');
          if (!num) return;
          var target = parseInt(num.textContent, 10) || 0, o = { x: 0 };
          gsap.to(o, { x: target, duration: 1.1, ease: 'power2.out', delay: 0.3 + k * 0.14, scrollTrigger: { trigger: pillars[0], start: 'top 90%', once: true },
            onUpdate: function () { num.textContent = ('0' + Math.round(o.x)).slice(-2); } });
        });
      }
      var slogan = about.querySelector('.guurti-slogan');
      var st = slogan && slogan.querySelector('.guurti-slogan__text');
      if (st) {
        var words = st.textContent.split(' ');
        st.setAttribute('aria-label', st.textContent);
        st.innerHTML = words.map(function (w) { return '<span class="w" aria-hidden="true">' + w.replace(/</g, '&lt;') + ' </span>'; }).join('');
        var tl2 = gsap.timeline({ scrollTrigger: { trigger: slogan, start: 'top 88%', once: true } });
        tl2.fromTo(slogan, { '--lx': 0 }, { '--lx': 1, duration: 1, ease: 'power3.out' }, 0)
           .from(st.querySelectorAll('.w'), { y: 26, opacity: 0, rotateX: -50, duration: 0.8, ease: 'power3.out', stagger: 0.07 }, 0.2);
      }
    }

    // Gallery tiles: curtain reveal
    document.querySelectorAll('.guurti-gallery-fallback figure').forEach(function (f, k) {
      gsap.from(f, { clipPath: 'inset(0 100% 0 0)', duration: 1, ease: 'power3.inOut', delay: k * 0.08, clearProps: 'clipPath', scrollTrigger: { trigger: f, start: 'top 90%', once: true } });
    });
  }
})();
